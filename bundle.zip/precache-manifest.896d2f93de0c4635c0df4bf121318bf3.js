self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f548a6c4d0e012c3c723815c72ab7b9f",
    "url": "/index.html"
  },
  {
    "revision": "2344312ae3487714cc1e",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "c744a788cd259c3449e7",
    "url": "/static/css/main.ae880ad0.chunk.css"
  },
  {
    "revision": "2344312ae3487714cc1e",
    "url": "/static/js/2.61b61320.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.61b61320.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c744a788cd259c3449e7",
    "url": "/static/js/main.ab701c0c.chunk.js"
  },
  {
    "revision": "1a021878c4c51e9797f6",
    "url": "/static/js/runtime-main.fc2a9dc8.js"
  },
  {
    "revision": "b528eaf852da05eb9fbb826b13d854d5",
    "url": "/static/media/roll.b528eaf8.svg"
  }
]);