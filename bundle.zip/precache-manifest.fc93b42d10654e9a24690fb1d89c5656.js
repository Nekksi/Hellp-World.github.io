self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "203be5bcf8310639af3d10fb7594ffea",
    "url": "/index.html"
  },
  {
    "revision": "8d5ca331940bd368a18b",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "0e7aa4c9ecc89b114413",
    "url": "/static/css/main.ae880ad0.chunk.css"
  },
  {
    "revision": "8d5ca331940bd368a18b",
    "url": "/static/js/2.46368a32.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.46368a32.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0e7aa4c9ecc89b114413",
    "url": "/static/js/main.8bc817dd.chunk.js"
  },
  {
    "revision": "1a021878c4c51e9797f6",
    "url": "/static/js/runtime-main.fc2a9dc8.js"
  },
  {
    "revision": "b528eaf852da05eb9fbb826b13d854d5",
    "url": "/static/media/roll.b528eaf8.svg"
  }
]);