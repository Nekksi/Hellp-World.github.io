self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8d49b176c824e715269212a9f1bf6faa",
    "url": "./index.html"
  },
  {
    "revision": "f1d38653f94b0f6dada6",
    "url": "./static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "e7e6940e3adde2a615cb",
    "url": "./static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "f1d38653f94b0f6dada6",
    "url": "./static/js/2.d50c0d66.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "./static/js/2.d50c0d66.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e7e6940e3adde2a615cb",
    "url": "./static/js/main.223890b7.chunk.js"
  },
  {
    "revision": "7df5595e9aa68f5b6c90",
    "url": "./static/js/runtime-main.246ca4c9.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "./static/media/persik1.4e1ec840.png"
  }
]);